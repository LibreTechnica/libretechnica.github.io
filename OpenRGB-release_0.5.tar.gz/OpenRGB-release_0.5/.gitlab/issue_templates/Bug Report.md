<!-- 
Found a bug?  Something isn't working as expected?  To help us keep track of the requests please start the title with [Bug Report]
-->

### Description of Bug
<!--
Please describe the bug.  Explain steps taken to reproduce the bug and what you expect the correct behavior to be.
-->


### Hardware Configuration
<!--
Please list the RGB hardware that you are using with OpenRGB.  If your bug does not relate to any one particular device or device type, or if the bug is in a part of the code not directly interacting with hardware, this is optional.
-->