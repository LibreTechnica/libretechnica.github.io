<!-- 
Have something you would like to see added to OpenRGB? Let us know here 
To help us keep track of the requests please start the title with [Feature Request]
-->

### Feature Request
<!--
Please explain the new feature you would like to see added in detail.  Explain how you think it should work and provide any mock-ups, code snippets, etc. that you think will help explain the feature.
-->
