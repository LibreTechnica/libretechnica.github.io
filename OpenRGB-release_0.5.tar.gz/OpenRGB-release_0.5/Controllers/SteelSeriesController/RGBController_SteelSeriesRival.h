/*-----------------------------------------*\
|  RGBController_SteelSeriesRival.h         |
|                                           |
|  Generic RGB Interface SteelSeriesRival   |
|  Class                                    |
|                                           |
|  B Horn (bahorn) 13/05/2020               |
\*-----------------------------------------*/

#pragma once

#include "RGBController.h"
#include "SteelSeriesRivalController.h"

class RGBController_SteelSeriesRival : public RGBController
{
public:
    RGBController_SteelSeriesRival(SteelSeriesRivalController* rival_ptr);

    void        SetupZones();

    void        ResizeZone(int zone, int new_size);

    void        DeviceUpdateLEDs();
    void        UpdateZoneLEDs(int zone);
    void        UpdateSingleLED(int led);

    void        SetCustomMode();
    void        DeviceUpdateMode();

private:
    SteelSeriesRivalController*     rival;
};
