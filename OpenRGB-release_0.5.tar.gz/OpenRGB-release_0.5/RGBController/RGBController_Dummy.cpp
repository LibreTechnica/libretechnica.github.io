/*-----------------------------------------*\
|  RGBController_Dummy.cpp                  |
|                                           |
|  Generic RGB Interface Dummy Class        |
|                                           |
|  Adam Honse (CalcProgrammer1) 2/25/2020   |
\*-----------------------------------------*/

#include "RGBController_Dummy.h"

RGBController_Dummy::RGBController_Dummy()
{

}

void RGBController_Dummy::SetupZones()
{

}

void RGBController_Dummy::ResizeZone(int /*zone*/, int /*new_size*/)
{

}

void RGBController_Dummy::DeviceUpdateLEDs()
{

}

void RGBController_Dummy::UpdateZoneLEDs(int /*zone*/)
{

}

void RGBController_Dummy::UpdateSingleLED(int /*led*/)
{

}

void RGBController_Dummy::SetCustomMode()
{

}

void RGBController_Dummy::DeviceUpdateMode()
{
    
}
